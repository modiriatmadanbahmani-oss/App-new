// Fix163: unified report template, Persian date selector, university navigation and money normalization.
const FIX163_EMPLOYERS='کارفرمایان: مهندس داداشی، مهندس نوری، مهندس بهمنی';
function fix163Now(){let d=new Date();return {date:d.toLocaleDateString('fa-IR',{timeZone:'Asia/Tehran'}),time:d.toLocaleTimeString('fa-IR',{timeZone:'Asia/Tehran'})}}
function fix163ReportHeader(title){let n=fix163Now();return `<header class="mineReportHeader"><h2>سامانه مدیریت هوشمند معادن</h2><h3>گزارش‌گیری معدن (${esc(title||window._reportName||'گزارش')})</h3><div>تاریخ: ${esc(n.date)} &nbsp; ساعت: ${esc(n.time)}</div></header>`}
function fix163ReportFooter(){return `<footer class="mineReportFooter"><p>${FIX163_EMPLOYERS}</p><div class="mineReportSign">امضاء: <span></span></div></footer>`}
function fix163Value(k,v){if(v==null||v==='')return '';if(typeof v==='object'&&v.data){return v.type?.startsWith('image/')?`<img class="reportImage" src="${v.data}" alt="${esc(k)}">`:`${esc(v.name||'فایل پیوست')}`}if(typeof v==='string'&&v.startsWith('data:image/'))return `<img class="reportImage" src="${v}" alt="${esc(k)}">`;return esc(String(v))}
function reportPrint(){let rows=window._filteredReport||[],title=window._reportName||'گزارش';let html=`<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><title>${esc(title)}</title><style>@page{size:A4 portrait;margin:13mm}body{font-family:Tahoma,Arial,sans-serif;direction:rtl;color:#111;font-size:11pt;line-height:1.65}.mineReportHeader{text-align:center;border-bottom:2px solid #333;padding-bottom:10px;margin-bottom:12px}.mineReportHeader h2{margin:0 0 4px}.mineReportHeader h3{margin:4px 0}section{page-break-inside:avoid;margin:8px 0;border:1px solid #aaa;padding:7px}table{width:100%;border-collapse:collapse;table-layout:fixed}th,td{border:1px solid #777;padding:5px;vertical-align:top;overflow-wrap:anywhere}th{width:32%}.reportImage{max-width:100%;max-height:140px;object-fit:contain}.mineReportFooter{margin-top:20px;page-break-inside:avoid;text-align:center}.mineReportSign{margin-top:20px;height:50px;border:1px solid #888;text-align:right;padding:8px}.mineReportSign span{display:inline-block;width:65%;height:38px}@media print{button{display:none}}</style></head><body>${fix163ReportHeader(title)}`;for(const x of rows){html+='<section><table>';for(const [k,v] of Object.entries(x)){if(k.startsWith('_')||v==null||v===''||(typeof v==='string'&&v.trim()===''))continue;html+=`<tr><th>${esc(k)}</th><td>${fix163Value(k,v)}</td></tr>`}html+='</table></section>'}html+=fix163ReportFooter()+'</body></html>';if(window.MinePrint?.printHtml){MinePrint.printHtml(html);return}let w=window.open('','_blank');if(!w){appToast('پنجره چاپ مسدود است؛ مجوز پنجره بازشو را فعال کنید.');return}w.document.write(html);w.document.close();setTimeout(()=>w.print(),600)}
function reportJPG(){let rows=window._filteredReport||[],title=window._reportName||'گزارش',W=1240,H=1754,pad=72,line=40;let items=[`سامانه مدیریت هوشمند معادن`,`گزارش‌گیری معدن (${title})`,...(()=>{let n=fix163Now();return ['تاریخ: '+n.date+'   ساعت: '+n.time,FIX163_EMPLOYERS,'','']})()];rows.forEach((r,i)=>{items.push('──────────── گزارش '+(i+1)+' ────────────');Object.entries(r).forEach(([k,v])=>{if(k.startsWith('_')||v==null||v==='')return;let val=(typeof v==='object'&&v.data)?(v.name||'فایل پیوست'):(typeof v==='string'&&v.startsWith('data:image/')?'[تصویر / امضاء]':String(v));items.push(k+': '+val)})});items.push('','محل امضاء:');let max=Math.floor((H-220)/line),chunks=[];for(let i=0;i<items.length;i+=max)chunks.push(items.slice(i,i+max));if(!chunks.length)chunks=[[]];chunks.forEach((part,idx)=>{let c=document.createElement('canvas');c.width=W;c.height=H;let ctx=c.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,W,H);ctx.fillStyle='#111';ctx.textAlign='right';ctx.font='28px Tahoma,Arial';let y=pad;part.forEach(t=>{ctx.fillText(t,W-pad,y);y+=line});ctx.strokeStyle='#777';ctx.strokeRect(pad,H-150,W-pad*2,90);ctx.font='20px Tahoma';ctx.textAlign='center';ctx.fillText('امضاء دستی',W/2,H-95);ctx.fillText('صفحه '+(idx+1)+' از '+chunks.length,W/2,H-pad/2);c.toBlob(b=>{if(!b){appToast('تولید JPG ناموفق');return}let a=document.createElement('a'),u=URL.createObjectURL(b);a.href=u;a.download=title.replace(/[\\/:*?"<>|]/g,'_')+'_'+idx+'.jpg';a.click();setTimeout(()=>URL.revokeObjectURL(u),2500)},'image/jpeg',.92)});if(chunks.length>1)appToast('گزارش در '+chunks.length+' تصویر A4 ذخیره می‌شود')}
// Jalali date picker widget: lightweight in-app picker without an external app.
function fix163Digits(s){return String(s||'').replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d))}
function fix163Calendar(input){if(!input||input.dataset.jalaliPicker==='1')return;input.dataset.jalaliPicker='1';input.type='text';input.placeholder='انتخاب تاریخ شمسی';input.readOnly=true;input.style.cursor='pointer';input.addEventListener('click',()=>fix163ShowCalendar(input));}
function fix163ShowCalendar(input){document.querySelector('.jalaliPickerPopup')?.remove();let today=new Date(),year=Number(fix163Digits(input.value).split('/')[0])||Number(today.toLocaleDateString('fa-IR',{year:'numeric'}).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d))),month=Number(fix163Digits(input.value).split('/')[1])||1;let pop=document.createElement('div');pop.className='jalaliPickerPopup';pop.style.cssText='position:fixed;z-index:99999;inset:15% 5% auto;background:white;border:2px solid #315a38;border-radius:14px;padding:14px;box-shadow:0 5px 30px #555;direction:rtl';let months=['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];pop.innerHTML=`<div style="display:flex;gap:8px;justify-content:center"><button type=button id=jpPrev>‹</button><select id=jpMonth>${months.map((m,i)=>`<option value="${i+1}" ${i+1===month?'selected':''}>${m}</option>`).join('')}</select><select id=jpYear>${Array.from({length:31},(_,i)=>year-15+i).map(y=>`<option ${y===year?'selected':''}>${y}</option>`).join('')}</select><button type=button id=jpNext>›</button></div><div id=jpDays style="display:grid;grid-template-columns:repeat(7,1fr);gap:5px;margin-top:10px"></div><button type=button id=jpClose style="width:100%;margin-top:10px">بستن</button>`;document.body.appendChild(pop);let draw=()=>{let m=Number(jpMonth.value),y=Number(jpYear.value),days=m<=6?31:m<=11?30:29;jpDays.innerHTML=Array.from({length:days},(_,i)=>`<button type=button data-day=${i+1}>${i+1}</button>`).join('');jpDays.querySelectorAll('button').forEach(b=>b.onclick=()=>{input.value=y+'/'+String(m).padStart(2,'0')+'/'+String(b.dataset.day).padStart(2,'0');input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));pop.remove()})};jpMonth.onchange=jpYear.onchange=draw;jpPrev.onclick=()=>{if(Number(jpMonth.value)===1){jpMonth.value=12;jpYear.value=Number(jpYear.value)-1}else jpMonth.value=Number(jpMonth.value)-1;draw()};jpNext.onclick=()=>{if(Number(jpMonth.value)===12){jpMonth.value=1;jpYear.value=Number(jpYear.value)+1}else jpMonth.value=Number(jpMonth.value)+1;draw()};jpClose.onclick=()=>pop.remove();draw()}
function fix163InstallDates(root=document){root.querySelectorAll('input[placeholder*="۱۴۰۵"],input[name*="تاریخ"],input[id*="From"],input[id*="To"],input[id*="from"],input[id*="to"]').forEach(fix163Calendar)}
// Wrap existing render functions to apply in-app date selectors to generated forms.
const _fix163ReportView=reportView;reportView=function(name){_fix163ReportView(name);fix163InstallDates(view)};
const _fix163LoadingReports=loadingReportsPage;loadingReportsPage=function(){_fix163LoadingReports();fix163InstallDates(view)};
const _fix163SamplePage=samplePage;samplePage=function(i=-1){_fix163SamplePage(i);fix163InstallDates(view);try{attachMoneyFormat(view)}catch(e){}};
const _fix163DriverWorkPage=driverWorkPage;driverWorkPage=function(){_fix163DriverWorkPage();fix163InstallDates(view);try{attachMoneyFormat(view)}catch(e){}};
const _fix163SampleReports=sampleReports;sampleReports=function(){_fix163SampleReports();fix163InstallDates(view)};
const _fix163DriverWorkReportsPage=driverWorkReportsPage;driverWorkReportsPage=function(){_fix163DriverWorkReportsPage();fix163InstallDates(view)};
// Independent university topic and lesson pages; back button returns to the topic list.
let _fix163UniTopic='',_fix163UniLessonIndex=null;function universityPage(topic='',articleIndex=null){_fix163UniTopic=topic;_fix163UniLessonIndex=articleIndex;let saved=load('records:دانشگاه معدن');if(!topic){view.innerHTML=`<div class="page universityFullPage"><button class="back" onclick="renderHome()">بازگشت</button><h2>🎓 دانشگاه معدن</h2><p>هر درس در صفحه مستقل نمایش داده می‌شود.</p><div class="grid">${universityTopics.map(t=>`<button class="tile" onclick="universityPage(${JSON.stringify(t)})">📚 ${esc(t)}</button>`).join('')}</div><h3>یادداشت‌های ذخیره‌شده</h3>${saved.map((r,i)=>`<div class=record><b>${esc(r['موضوع'])} — ${esc(r['عنوان'])}</b><p>${esc(r['شرح']||'')}</p><button onclick="delUniversityItem(${i})">حذف</button></div>`).join('')||'یادداشتی ثبت نشده'}</div>`;return}let lib=uniLibrary[topic];if(!lib){universityPage();return}if(articleIndex!==null){let lesson=lib.chapters[articleIndex];view.innerHTML=`<div class="page universityFullPage"><button class="back" onclick="universityPage(${JSON.stringify(topic)})">بازگشت به ${esc(topic)}</button><h2>${esc(topic)}</h2><article class=record><h3>${esc(lesson?.[0]||'درس')}</h3><p style="white-space:pre-wrap;line-height:2">${esc(lesson?.[1]||'')}</p><button onclick="uniSaveStudy(${JSON.stringify(topic)},${articleIndex})">ذخیره یادداشت این درس</button></article></div>`;return}view.innerHTML=`<div class="page universityFullPage"><button class="back" onclick="universityPage()">بازگشت به فهرست دانشگاه</button><h2>${esc(topic)}</h2><p>${esc(lib.intro||'')}</p><div class="grid">${lib.chapters.map((c,i)=>`<button class="tile" onclick="universityPage(${JSON.stringify(topic)},${i})">📖 ${esc(c[0])}</button>`).join('')}</div><h3>منابع</h3><ul>${lib.refs.map(r=>`<li><a href="${r[1]}" target=_blank rel=noopener>${esc(r[0])}</a></li>`).join('')}</ul></div>`}
// Format all numeric money-like inputs and avoid value-as-string money calculation.
const _fix163MoneyFormat=attachMoneyFormat;attachMoneyFormat=function(root){_fix163MoneyFormat(root);if(!root)return;root.querySelectorAll('input').forEach(el=>{if(isMoneyField(el.name)&&!el.dataset.fix163Money){el.dataset.fix163Money='1';el.addEventListener('blur',()=>{el.value=moneyFormat(el.value)})}})};
// Add report buttons in loading report view, and retain the filters before export.
const _fix163BuildLoadingReport=buildLoadingReport;buildLoadingReport=function(){_fix163BuildLoadingReport();let b=document.getElementById('lrRows');if(b&&!b.querySelector('.fix163Export'))b.insertAdjacentHTML('afterbegin','<div class="list fix163Export"><button onclick="reportJPG()">ذخیره JPG</button><button onclick="reportPrint()">PDF / چاپ</button></div>')};
const _fix163LoadingPage=loadingPage;loadingPage=function(i=-1){_fix163LoadingPage(i);fix163InstallDates(view);try{attachMoneyFormat(view)}catch(e){}};
const _fix163FormPage=formPage;formPage=function(n,f,i=-1){_fix163FormPage(n,f,i);try{attachMoneyFormat(view)}catch(e){}};

// FIX181: Inline saved-image deletion controls with confirmation; preserve existing images on edit.
(function fix181InlineMineImages(){
 const originalDetail=window.mineDetail;
 if(typeof originalDetail==='function') window.mineDetail=function(j){
   originalDetail(j); const panel=document.querySelector('#view .page'); if(!panel)return;
   const mine=load('mines')[j]; if(!mine)return;
   ['تصویر معدن','تصویر مجوز','تصویر محدوده'].forEach(key=>{
     const present=mine[key]; if(!present)return;
     const section=[...panel.querySelectorAll('section.record')].find(s=>s.querySelector('img[alt="'+key+'"]'));
     if(section){const title=section.querySelector('b'); if(title){const btn=document.createElement('button');btn.type='button';btn.className='danger inlineMineImageDelete';btn.textContent='حذف';btn.style.marginInlineStart='8px';btn.onclick=()=>removeMineImage(j,key);title.insertAdjacentElement('afterend',btn);}}
   });
   const old=panel.querySelector('section.record:has(b)');
   panel.querySelectorAll('section').forEach(s=>{if((s.textContent||'').includes('مدیریت تصاویر پرونده'))s.remove()});
 };
})();
function fix181ClearMineImageField(btn){const key=btn.dataset.image,inp=document.querySelector('#mineForm input[type=file][name="'+key+'"]');if(!inp)return;if(!confirm('آیا مطمئن هستید که می‌خواهید فایل انتخاب‌شده «'+key+'» را پاک کنید؟'))return;inp.value='';const preview=document.querySelector('[data-preview="'+key+'"]');if(preview)preview.textContent='';}
// Ensure bootstrap password hash is exactly the requested default only when no password has been stored.
(function fix181AdminBootstrap(){try{const h='4298b5ef8eece53accd323a569236379af84af1019d350781d0e3f4c1f8fefe4';if(!localStorage.getItem('mineAdminHash'))localStorage.setItem('mineAdminHash',h);}catch(e){console.warn('Admin password bootstrap deferred',e)}})();

// FIX182: robust University Mine navigation (topic and lesson views are separate pages).
(function fix182UniversityNavigation(){
 const canonical=t=>{if(typeof fix165FindTopic==='function')return fix165FindTopic(t);return Object.keys(uniLibrary||{}).find(k=>String(k).trim()===String(t).trim())};
 window.universityPage=function(topic='',lessonIndex=null){
  try{
   if(!topic){view.innerHTML=`<div class="page universityFullPage"><button class="back" type="button" onclick="renderHome()">بازگشت</button><h2>🎓 دانشگاه معدن</h2><p>برای ورود، موضوع موردنظر را انتخاب کنید.</p><div class="grid">${universityTopics.map(t=>`<button class="tile" type="button" onclick="universityPage(${JSON.stringify(t)})">📚 ${esc(t)}</button>`).join('')}</div><h3>یادداشت‌های ذخیره‌شده</h3>${load('records:دانشگاه معدن').map((r,i)=>`<div class="record"><b>${esc(r['موضوع']||'')} — ${esc(r['عنوان']||'')}</b><p>${esc(r['شرح']||'')}</p><button type="button" onclick="delUniversityItem(${i})">حذف</button></div>`).join('')||'یادداشتی ثبت نشده'}</div>`;return}
   const key=canonical(topic);if(!key||!uniLibrary[key]){appToast('موضوع دانشگاه یافت نشد');window.universityPage();return}
   const lib=uniLibrary[key];if(lessonIndex!==null){const lesson=lib.chapters[lessonIndex];if(!lesson){window.universityPage(key);return}view.innerHTML=`<div class="page universityFullPage"><button class="back" type="button" onclick="universityPage(${JSON.stringify(key)})">بازگشت به ${esc(key)}</button><h2>${esc(key)}</h2><article class="record"><h3>${esc(lesson[0]||'درس')}</h3><p style="white-space:pre-wrap;line-height:2">${esc(lesson[1]||'')}</p><button type="button" onclick="uniSaveStudy(${JSON.stringify(key)},${lessonIndex})">ذخیره یادداشت این درس</button></article></div>`;return}
   view.innerHTML=`<div class="page universityFullPage"><button class="back" type="button" onclick="universityPage()">بازگشت به فهرست دانشگاه</button><h2>${esc(key)}</h2><p>${esc(lib.intro||'')}</p><div class="grid">${lib.chapters.map((c,i)=>`<button class="tile" type="button" onclick="universityPage(${JSON.stringify(key)},${i})">📖 ${esc(c[0])}</button>`).join('')}</div><h3>منابع</h3><ul>${(lib.refs||[]).map(r=>`<li><a href="${r[1]}" target="_blank" rel="noopener">${esc(r[0])}</a></li>`).join('')}</ul></div>`;
  }catch(e){console.error('University page error',e);view.innerHTML=`<div class="page"><button class="back" type="button" onclick="renderHome()">بازگشت</button><h2>دانشگاه معدن</h2><p>خطا در بازکردن درس. دوباره تلاش کنید.</p><button type="button" onclick="universityPage()">بازگشت به فهرست</button></div>`;appToast('خطا در نمایش دانشگاه معدن')}
 };
})();
/* FIX184 inline delete controls */
(function fix184InlineControls(){function bind(){const form=document.getElementById('mineForm');if(!form)return;['تصویر معدن','تصویر مجوز','تصویر محدوده'].forEach(key=>{const inp=form.querySelector('input[type=file][name="'+key+'"]'),btn=form.querySelector('button.inlineMineImageDelete[data-image="'+key+'"]'),preview=form.querySelector('[data-preview="'+key+'"]');if(inp&&btn&&!btn.dataset.fix184Inline){btn.dataset.fix184Inline='1';const w=inp.parentElement;w.style.display='flex';w.style.flexWrap='wrap';w.style.alignItems='center';w.style.gap='8px';btn.style.margin='0';btn.style.flex='0 0 auto';inp.style.flex='1 1 220px';inp.style.minWidth='0';w.appendChild(btn)}if(preview){preview.textContent='';preview.style.display='none'}})}const v=document.getElementById('view');if(v&&!v.dataset.fix184Observer){v.dataset.fix184Observer='1';new MutationObserver(bind).observe(v,{childList:true,subtree:true})}bind()})();

// FIX185: enforce default admin credential only when no credential is present, and make image controls inline.
(function fix185(){try{const expected='4298b5ef8eece53accd323a569236379af84af1019d350781d0e3f4c1f8fefe4';if(!localStorage.getItem('mineAdminHash'))localStorage.setItem('mineAdminHash',expected)}catch(e){};function inline(){const f=document.getElementById('mineForm');if(!f)return;['تصویر معدن','تصویر مجوز','تصویر محدوده'].forEach(k=>{const i=f.querySelector('input[type=file][name="'+k+'"]'),b=f.querySelector('button[data-image="'+k+'"]');if(i&&b){let p=i.parentElement;p.style.display='flex';p.style.alignItems='center';p.style.flexWrap='wrap';p.style.gap='8px';b.style.margin='0';b.style.flex='0 0 auto';i.style.flex='1 1 220px';p.appendChild(b)}const prev=f.querySelector('[data-preview="'+k+'"]');if(prev){prev.textContent='';prev.style.display='none'}})}const v=document.getElementById('view');if(v&&!v.dataset.fix185){v.dataset.fix185='1';new MutationObserver(inline).observe(v,{childList:true,subtree:true})}inline()})();

// FIX186: enforce a single calculator layout and left-to-right digit entry.
(function fix186CalculatorLayout(){
 if(typeof window.calcPage!=='function')return;
 const base=window.calcPage;
 window.calcPage=function(){
  base();
  const p=document.querySelector('#view .calcPage'); if(!p)return;
  p.classList.add('calcExact');
  const back=p.querySelector('.calcTop .back,button.back');
  if(back){back.textContent='بازگشت';back.style.position='absolute';back.style.top='8px';back.style.left='8px';back.style.zIndex='2';}
  const title=p.querySelector('.calcTitle');if(title){title.textContent='ماشین حساب';title.classList.add('calcExactTitle');}
  const inp=p.querySelector('#expr');if(inp){inp.setAttribute('dir','ltr');inp.style.direction='ltr';inp.style.textAlign='right';inp.setAttribute('inputmode','decimal');}
  p.querySelectorAll('.calcKey').forEach(b=>{const t=b.textContent.trim();b.classList.toggle('calcOperator',['÷','×','−','+','%','⌫','AC','±'].includes(t));b.classList.toggle('calcEqual',t==='=');});
  const grid=p.querySelector('.calcgrid:not(.calcScientific)');if(grid){grid.style.direction='ltr';grid.style.gridTemplateColumns='repeat(4,minmax(0,1fr))';}
 };
})();

// FIX188: definitive repairs for image-field layout, calculator, and university navigation.
(function fix188(){
 const viewEl=document.getElementById('view');
 function arrangeImages(){const f=document.getElementById('mineForm');if(!f)return;
  ['تصویر معدن','تصویر مجوز','تصویر محدوده'].forEach(k=>{
   const input=f.querySelector('input[type=file][name="'+k+'"]'); if(!input)return;
   const btn=f.querySelector('button[data-image="'+k+'"],button.inlineMineImageDelete[data-image="'+k+'"]');
   const preview=f.querySelector('[data-preview="'+k+'"]');
   let wrap=input.closest('.fix188ImageRow');
   if(!wrap){wrap=document.createElement('div');wrap.className='fix188ImageRow';
    const label=[...f.querySelectorAll('label')].find(x=>x.textContent.trim()===k);
    if(label){label.insertAdjacentElement('afterend',wrap);wrap.appendChild(input);if(btn)wrap.appendChild(btn);if(preview)wrap.appendChild(preview)}else{input.parentNode.insertBefore(wrap,input);wrap.appendChild(input);if(btn)wrap.appendChild(btn);if(preview)wrap.appendChild(preview)}
   }else{if(input.parentElement!==wrap)wrap.appendChild(input);if(btn&&btn.parentElement!==wrap)wrap.appendChild(btn);if(preview&&preview.parentElement!==wrap)wrap.appendChild(preview)}
   if(btn){btn.textContent='حذف';btn.classList.add('fix188Delete');btn.onclick=()=>{if(!confirm('آیا مطمئن هستید که می‌خواهید '+k+' حذف شود؟'))return;input.value='';if(preview){preview.textContent='';preview.style.display='none'};const oldWrap=wrap;oldWrap.classList.remove('has-file');};}
   if(preview){preview.textContent='';preview.style.display='none'}
  });
 }
 if(viewEl&&!viewEl.dataset.fix188Observer){viewEl.dataset.fix188Observer='1';new MutationObserver(arrangeImages).observe(viewEl,{childList:true,subtree:true});}arrangeImages();
 // Robust University Mine entry and topic/lesson handlers. Always use canonical library keys.
 const norm=t=>String(t||'').replace(/[\u200c\u200d\u200e\u200f\s]/g,'').replace(/[ي]/g,'ی').replace(/[ك]/g,'ک');
 window.universityPage=function(topic='',lessonIndex=null){try{
  if(!topic){view.innerHTML='<div class="page universityFullPage"><button class="back" onclick="renderHome()">بازگشت</button><h2>🎓 دانشگاه معدن</h2><p>موضوع را انتخاب کنید.</p><div class="grid">'+(universityTopics||[]).map(t=>'<button class="tile" onclick="universityPage('+JSON.stringify(t)+')">📚 '+esc(t)+'</button>').join('')+'</div></div>';return;}
  const key=Object.keys(uniLibrary||{}).find(k=>norm(k)===norm(topic));if(!key){appToast('موضوع یافت نشد');return window.universityPage();}const lib=uniLibrary[key];
  if(lessonIndex!==null){const c=lib.chapters?.[Number(lessonIndex)];if(!c){return window.universityPage(key)}view.innerHTML='<div class="page universityFullPage"><button class="back" onclick="universityPage('+JSON.stringify(key)+')">بازگشت</button><h2>'+esc(key)+'</h2><article class="record"><h3>'+esc(c[0]||'درس')+'</h3><p style="white-space:pre-wrap;line-height:2">'+esc(c[1]||'')+'</p><button onclick="uniSaveStudy('+JSON.stringify(key)+','+Number(lessonIndex)+')">ذخیره یادداشت</button></article></div>';return;}
  view.innerHTML='<div class="page universityFullPage"><button class="back" onclick="renderHome()">بازگشت</button><h2>'+esc(key)+'</h2><p>'+esc(lib.intro||'')+'</p><div class="grid">'+(lib.chapters||[]).map((c,i)=>'<button class="tile" onclick="universityPage('+JSON.stringify(key)+','+i+')">📖 '+esc(c[0])+'</button>').join('')+'</div><h3>منابع</h3><ul>'+(lib.refs||[]).map(r=>'<li><a href="'+r[1]+'" target="_blank" rel="noopener">'+esc(r[0])+'</a></li>').join('')+'</ul></div>';
 }catch(e){console.error('University navigation',e);view.innerHTML='<div class="page"><button class="back" onclick="renderHome()">بازگشت</button><h2>دانشگاه معدن</h2><p>خطای نمایش: '+esc(e.message||'')+'</p></div>';}};
})();

// FIX190: calculator keypad layout matching the supplied reference (operators in right column).
(function fix190CalculatorReference(){
 const cssFix=()=>{const p=document.querySelector('#view .calcPage');if(!p)return; p.classList.add('calcExact','calcReference');const g=p.querySelector('.calcgrid:not(.calcScientific)');if(!g)return;g.setAttribute('dir','ltr');g.style.direction='ltr';g.style.display='grid';g.style.gridTemplateColumns='repeat(4,minmax(0,1fr))';g.style.gridTemplateRows='repeat(5,minmax(0,1fr))';g.style.gridAutoFlow='row';g.querySelectorAll('.calcKey').forEach((b,i)=>{b.style.gridColumn='';b.style.gridRow='';b.style.order='';});};
 if(typeof window.calcPage==='function'){const old=window.calcPage;window.calcPage=function(){old();cssFix();};}
 document.addEventListener('click',e=>{if(e.target.closest('[onclick*="calcPage"]'))setTimeout(cssFix,0);});
})();
// FIX192: consolidated University Mine topic/lesson navigation.
(function fix192University(){
 const norm=t=>String(t||'').replace(/[\u200c\u200d\u200e\u200f\s]/g,'').replace(/[ي]/g,'ی').replace(/[ك]/g,'ک');
 window.universityPage=function(topic='',lessonIndex=null){try{
  if(!topic){view.innerHTML='<div class="page universityFullPage"><button class="back" type="button" onclick="renderHome()">بازگشت</button><h2>🎓 دانشگاه معدن</h2><p>موضوع را انتخاب کنید.</p><div class="grid">'+universityTopics.map(t=>'<button class="tile" type="button" onclick="universityPage('+JSON.stringify(t)+')">📚 '+esc(t)+'</button>').join('')+'</div><h3>یادداشت‌های ذخیره‌شده</h3>'+load('records:دانشگاه معدن').map((r,i)=>'<div class="record"><b>'+esc(r['موضوع']||'')+' — '+esc(r['عنوان']||'')+'</b><p>'+esc(r['شرح']||'')+'</p><button type="button" onclick="delUniversityItem('+i+')">حذف</button></div>').join('')+'</div>';return;}
  const key=Object.keys(uniLibrary||{}).find(k=>norm(k)===norm(topic));if(!key){appToast('موضوع دانشگاه یافت نشد');return window.universityPage();}
  const lib=uniLibrary[key],chapters=lib.chapters||[];
  if(lessonIndex!==null){const idx=Number(lessonIndex),lesson=chapters[idx];if(!lesson)return window.universityPage(key);view.innerHTML='<div class="page universityFullPage"><button class="back" type="button" onclick="universityPage('+JSON.stringify(key)+')">بازگشت</button><h2>'+esc(key)+'</h2><article class="record"><h3>'+esc(lesson[0]||'درس')+'</h3><p style="white-space:pre-wrap;line-height:2">'+esc(lesson[1]||'')+'</p><button type="button" onclick="uniSaveStudy('+JSON.stringify(key)+','+idx+')">ذخیره یادداشت</button></article></div>';return;}
  view.innerHTML='<div class="page universityFullPage"><button class="back" type="button" onclick="universityPage()">بازگشت به فهرست</button><h2>'+esc(key)+'</h2><p>'+esc(lib.intro||'')+'</p><div class="grid">'+chapters.map((c,i)=>'<button class="tile" type="button" onclick="universityPage('+JSON.stringify(key)+','+i+')">📖 '+esc(c[0]||'درس')+'</button>').join('')+'</div><h3>منابع</h3><ul>'+(lib.refs||[]).map(r=>'<li><a href="'+esc(r[1]||'#')+'" target="_blank" rel="noopener">'+esc(r[0]||'منبع')+'</a></li>').join('')+'</ul></div>';
 }catch(e){console.error('FIX192 University',e);view.innerHTML='<div class="page"><button class="back" type="button" onclick="renderHome()">بازگشت</button><h2>دانشگاه معدن</h2><p>خطا در نمایش: '+esc(e.message||'')+'</p></div>';}};
})();

/* FIX193: image delete controls inside their bordered upload rows; calculator matches supplied phone reference. */
(function fix193UI(){
 const root=document.getElementById('view');
 function fixImageRows(){
  const f=document.getElementById('mineForm'); if(!f)return;
  ['تصویر معدن','تصویر مجوز','تصویر محدوده'].forEach(k=>{
   const input=f.querySelector('input[type="file"][name="'+k+'"]');
   if(!input)return;
   const label=[...f.querySelectorAll('label')].find(x=>x.textContent.trim()===k);
   let btn=f.querySelector('button[data-image="'+k+'"]');
   const preview=f.querySelector('[data-preview="'+k+'"]');
   let row=input.closest('.fix193ImageRow,.fix188ImageRow');
   if(row){row.classList.add('fix193ImageRow');}
   if(!row){row=document.createElement('div');row.className='fix193ImageRow';if(label)label.insertAdjacentElement('afterend',row);else input.insertAdjacentElement('beforebegin',row);}
   if(input.parentElement!==row)row.appendChild(input);
   if(btn&&btn.parentElement!==row)row.appendChild(btn);
   if(preview&&preview.parentElement!==row)row.appendChild(preview);
   if(btn){btn.classList.add('fix193Delete');btn.textContent='حذف';btn.type='button';btn.onclick=()=>{if(!confirm('آیا از حذف '+k+' مطمئن هستید؟'))return;input.value='';if(preview){preview.textContent='';preview.style.display='none';}row.classList.remove('has-file');};}
   if(preview)preview.style.display='none';
   row.querySelectorAll('.fix193Delete').forEach((b,i)=>{if(i>0)b.remove();});
  });
 }
 if(root&&!root.dataset.fix193Images){root.dataset.fix193Images='1';new MutationObserver(fixImageRows).observe(root,{childList:true,subtree:true});}
 fixImageRows();
 const originalCalc=window.calcPage;
 if(typeof originalCalc==='function'&&!window._fix193CalcWrapped){
  window._fix193CalcWrapped=true;
  window.calcPage=function(){
   originalCalc();
   const p=document.querySelector('#view .calcPage');if(!p)return;
   p.classList.add('calc193Exact');
   ['.calcTop','.calcAdvanced','.calcActions','.calcHistoryDetails'].forEach(sel=>{const el=p.querySelector(sel);if(el)el.remove();});
   const result=p.querySelector('#result');if(result)result.remove();
   const expr=p.querySelector('#expr');if(expr){expr.value='';expr.placeholder='0';expr.setAttribute('inputmode','decimal');expr.setAttribute('dir','ltr');}
   const footer=document.getElementById('appFooter');if(footer)footer.style.display='none';
  };
  const oldHome=window.renderHome;
  if(typeof oldHome==='function')window.renderHome=function(){const r=oldHome.apply(this,arguments);const f=document.getElementById('appFooter');if(f)f.style.display='';return r;};
 }
})();

/* FIX194: keep the mine image upload rows clean; remove redundant status/delete wording. */
(function fix194CleanMineImageText(){
 const root=document.getElementById('view');
 function clean(){
  const f=document.getElementById('mineForm');if(!f)return;
  ['تصویر معدن','تصویر مجوز','تصویر محدوده'].forEach(k=>{
   const input=f.querySelector('input[type="file"][name="'+k+'"]');if(!input)return;
   const row=input.closest('.fix193ImageRow,.fix188ImageRow,.fix189-file-row')||input.parentElement;
   const preview=f.querySelector('[data-preview="'+k+'"]');
   if(preview){preview.textContent='';preview.innerHTML='';preview.style.display='none';preview.removeAttribute('data-remove');}
   const buttons=[...row.querySelectorAll('button[data-image="'+k+'"],button.inlineMineImageDelete,button.clearMineImage,button.fix193Delete,button.fix188Delete')];
   const btn=buttons[0];
   buttons.slice(1).forEach(b=>b.remove());
   if(btn){
    btn.type='button';btn.textContent='🗑';btn.setAttribute('aria-label','پاک کردن فایل انتخاب‌شده');btn.title='پاک کردن فایل انتخاب‌شده';
    btn.style.minWidth='42px';btn.style.width='42px';btn.style.padding='8px 0';btn.style.margin='0';btn.style.flex='0 0 42px';
    btn.onclick=()=>{if(!confirm('فایل انتخاب‌شده پاک شود؟'))return;input.value='';if(preview){preview.textContent='';preview.innerHTML='';preview.style.display='none';}row.classList.remove('has-file');};
   }
   row.querySelectorAll('.mineImagePreview').forEach(el=>{el.textContent='';el.style.display='none';});
  });
 }
 if(root&&!root.dataset.fix194Observer){root.dataset.fix194Observer='1';new MutationObserver(clean).observe(root,{childList:true,subtree:true});}
 clean();
})();

/* FIX195: definitive mine-list trash controls, in-app Persian confirmation, and reference calculator. */
(function fix195FinalUI(){
 const $=(s,r=document)=>r.querySelector(s);
 function ask(message){
  return new Promise(resolve=>{
   const old=$('#fix195Confirm'); if(old)old.remove();
   const box=document.createElement('div');box.id='fix195Confirm';box.className='fix195Confirm';
   box.innerHTML='<div class="fix195Dialog" role="dialog" aria-modal="true"><div class="fix195DialogTitle">تأیید عملیات</div><div class="fix195DialogText"></div><div class="fix195DialogActions"><button type="button" class="fix195Cancel">لغو</button><button type="button" class="fix195Ok">تأیید</button></div></div>';
   $('.fix195DialogText',box).textContent=message;
   const done=v=>{box.remove();resolve(v)};
   $('.fix195Cancel',box).onclick=()=>done(false);
   $('.fix195Ok',box).onclick=()=>done(true);
   box.addEventListener('click',e=>{if(e.target===box)done(false)});
   document.addEventListener('keydown',function esc(e){if(e.key==='Escape'&&box.isConnected){document.removeEventListener('keydown',esc);done(false)}});
   document.body.appendChild(box);
  });
 }
 window.fix195Ask=ask;
 // Replace the mine-list text delete action with a trash icon beside the mine title.
 function decorateMineRows(){
  const host=$('#mineRows');if(!host)return;
  host.querySelectorAll('.record').forEach(card=>{
   const del=card.querySelector('button[onclick^="delMine("]');
   const title=card.querySelector('b');
   if(del){
    del.textContent='';del.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3m3 0-1 13H7L6 7m4 4v5m4-5v5"/></svg>';
    del.classList.add('fix195Trash');del.type='button';del.title='حذف معدن';del.setAttribute('aria-label','حذف معدن');
    if(title&&del.parentElement!==title.parentElement){title.insertAdjacentElement('afterend',del);}
    else if(title&&del.previousElementSibling!==title){title.insertAdjacentElement('afterend',del);}
   }
  });
 }
 const oldMines=window.minesPage;
 if(typeof oldMines==='function'){
  window.minesPage=function(){const r=oldMines.apply(this,arguments);decorateMineRows();const host=$('#mineRows');if(host&&!host.dataset.fix195){host.dataset.fix195='1';new MutationObserver(decorateMineRows).observe(host,{childList:true,subtree:true});}return r;};
 }
 window.delMine=async function(j){
  if(!await ask('آیا از حذف این معدن مطمئن هستید؟'))return;
  const a=load('mines');a.splice(j,1);localStorage.setItem('mines',JSON.stringify(a));window.minesPage();
 };
 // Handle the upload-row trash and saved-image delete controls before old native-confirm handlers.
 document.addEventListener('click',async e=>{
  const b=e.target.closest('.fix193Delete,.removeExistingMineImage');
  if(!b)return;
  e.preventDefault();e.stopImmediatePropagation();
  if(b.classList.contains('removeExistingMineImage')){
   if(!await ask('آیا فایل ذخیره‌شده حذف شود؟'))return;
   const preview=b.closest('.mineImagePreview');if(preview){preview.dataset.remove='1';preview.textContent='';preview.style.display='none';}
   return;
  }
  const row=b.closest('.fix193ImageRow,.fix188ImageRow')||b.parentElement;
  const input=row.querySelector('input[type="file"]');
  if(!await ask('آیا فایل انتخاب‌شده پاک شود؟'))return;
  if(input)input.value='';
  const preview=row.querySelector('.mineImagePreview,[data-preview]');
  if(preview){preview.textContent='';preview.innerHTML='';preview.style.display='none';}
  row.classList.remove('has-file');
 },true);
 // Saved images in the mine detail screen.
 window.removeMineImage=async function(j,key){
  if(!await ask('آیا تصویر «'+key+'» از پرونده معدن حذف شود؟'))return;
  const a=load('mines'),x=a[j];if(!x)return;delete x[key];a[j]=x;localStorage.setItem('mines',JSON.stringify(a));mineDetail(j);appToast('تصویر حذف شد');
 };
 // A clean full-screen keypad. Preserve the existing safe calculator engine.
 const baseCalc=window.calcPage;
 window.calcPage=function(){
  const labels=['AC','⌫','%','÷','7','8','9','×','4','5','6','−','1','2','3','+','±','0','.','='];
  view.innerHTML='<div class="calc195Page"><div class="calc195Display"><input id="expr" class="calc195Input" value="" placeholder="0" inputmode="decimal" dir="ltr" autocomplete="off"><div id="result" hidden>0</div><select id="calcPrecision" hidden><option selected>8</option></select><select id="calcAngle" hidden><option value="deg" selected>درجه</option></select></div><div class="calc195Grid">'+labels.map(k=>'<button type="button" class="calc195Key '+(['AC','⌫','%','÷','×','−','+','±'].includes(k)?'calc195Op ':'')+(k==='='?'calc195Equal':'')+'" data-key="'+k+'">'+(k==='⌫'?'<svg viewBox="0 0 24 24"><path d="M9 5H21V19H9L2 12Z"/><path d="m13 9 5 6m0-6-5 6"/></svg>':k==='±'?'<svg viewBox="0 0 24 24"><path d="M5 8a7 7 0 0 1 12-3l2 2M19 16a7 7 0 0 1-12 3l-2-2"/><path d="M17 2v5h5M7 22v-5H2"/><rect x="8" y="8" width="8" height="8" rx="2"/></svg>':k)+'</button>').join('')+'</div></div>';
  const mainHeader=$('#main > header'),footer=$('#appFooter');
  if(mainHeader)mainHeader.style.display='none';if(footer)footer.style.display='none';
  const grid=$('.calc195Grid');
  grid.addEventListener('click',e=>{
   const b=e.target.closest('[data-key]');if(!b)return;
   const k=b.dataset.key;
   if(k==='='){try{const v=calcSafeEvaluate(expr.value);const out=Number(v.toFixed(8)).toString();expr.value=out;result.textContent=out;window.calcLast=out;}catch(err){appToast(err.message||'عبارت نامعتبر');}return;}
   calcKey(k);
  });
  const input=$('#expr');input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();grid.querySelector('[data-key="="]').click();}});
 };
 // Restore normal chrome when leaving calculator.
 const oldHome=window.renderHome;
 if(typeof oldHome==='function')window.renderHome=function(){const r=oldHome.apply(this,arguments);const h=$('#main > header'),f=$('#appFooter');if(h)h.style.display='';if(f)f.style.display='';return r;};
})();

/* FIX196: put one trash icon INSIDE each mine attachment box; remove external text buttons. */
(function fix196TrashInsideUploadBoxes(){
 const root=document.getElementById('view');
 const keys=['تصویر معدن','تصویر مجوز','تصویر محدوده'];
 const icon='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3m3 0-1 13H7L6 7m4 4v5m4-5v5"/></svg>';
 function arrange(){
  const f=document.getElementById('mineForm');if(!f)return;
  keys.forEach(key=>{
   const input=f.querySelector('input[type="file"][name="'+key+'"]');if(!input)return;
   const label=[...f.querySelectorAll('label')].find(x=>x.textContent.trim()===key);
   // Reuse an existing upload wrapper created by earlier layout patches.
   // This avoids leaving an empty outlined box or fighting older MutationObservers.
   let row=input.closest('.fix196UploadBox,.fix193ImageRow,.fix188ImageRow,.fix189-file-row');
   if(!row){row=document.createElement('div');if(label)label.insertAdjacentElement('afterend',row);else input.insertAdjacentElement('beforebegin',row);}
   row.classList.add('fix196UploadBox','fix193ImageRow','fix188ImageRow');
   if(input.parentElement!==row)row.appendChild(input);
   let btn=row.querySelector('.fix196TrashButton');
   if(!btn){
    btn=document.createElement('button');btn.type='button';btn.className='fix196TrashButton';btn.innerHTML=icon;btn.title='حذف فایل';btn.setAttribute('aria-label','حذف فایل');row.appendChild(btn);
   }
   const preview=f.querySelector('[data-preview="'+key+'"]');
   if(preview){preview.textContent='';preview.innerHTML='';preview.style.display='none';if(preview.parentElement!==row)row.appendChild(preview);}
   // Remove all older standalone delete controls for this upload field.
   [...f.querySelectorAll('button')].forEach(b=>{
    if(b===btn)return;
    const marked=b.dataset.image===key||b.classList.contains('inlineMineImageDelete')||b.classList.contains('clearMineImage')||b.classList.contains('fix193Delete')||b.classList.contains('fix188Delete');
    if(marked && !row.contains(b))b.remove();
    else if(marked && b!==btn)b.remove();
   });
   if(!btn.dataset.bound){
    btn.dataset.bound='1';
    btn.addEventListener('click',async e=>{
     e.preventDefault();e.stopPropagation();
     const ask=window.fix195Ask;
     const ok=ask?await ask('فایل انتخاب‌شده حذف شود؟'):window.confirm('فایل انتخاب‌شده حذف شود؟');
     if(!ok)return;
     input.value='';
     if(preview){preview.textContent='';preview.innerHTML='';preview.style.display='none';}
     row.classList.remove('has-file');
    });
   }
  });
 }
 if(root&&!root.dataset.fix196Observer){
  root.dataset.fix196Observer='1';
  new MutationObserver(arrange).observe(root,{childList:true,subtree:true});
 }
 arrange();
})();
