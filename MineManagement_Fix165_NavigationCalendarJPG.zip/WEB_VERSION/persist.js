/* Durable local record mirror using IndexedDB. Hydrate localStorage before app startup. */
(async()=>{
 const DB='MineManagementLocalDB', STORE='kv', VERSION=1;
 function openDB(){return new Promise((resolve,reject)=>{let r=indexedDB.open(DB,VERSION);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(STORE))r.result.createObjectStore(STORE)};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
 const db=await openDB();
 const readAll=()=>new Promise((resolve,reject)=>{let tx=db.transaction(STORE,'readonly'),s=tx.objectStore(STORE),r=s.getAllKeys(),v=s.getAll();tx.oncomplete=()=>resolve(r.result.map((k,i)=>[k,v.result[i]]));tx.onerror=()=>reject(tx.error)});
 const originalSet=Storage.prototype.setItem,originalRemove=Storage.prototype.removeItem,originalClear=Storage.prototype.clear;
 const mirror=(key,value)=>{try{let tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).put(value,key)}catch(e){console.warn('IndexedDB mirror write failed',e)}};
 // Restore stored values if local cache is missing, otherwise seed DB from local cache.
 let entries=await readAll();for(let [k,v] of entries){if(localStorage.getItem(k)===null)originalSet.call(localStorage,k,v)}
 for(let i=0;i<localStorage.length;i++){let k=localStorage.key(i);if(k!==null)mirror(k,localStorage.getItem(k))}
 Storage.prototype.setItem=function(k,v){originalSet.call(this,k,v);if(this===localStorage)mirror(String(k),String(v))};
 Storage.prototype.removeItem=function(k){originalRemove.call(this,k);if(this===localStorage){try{db.transaction(STORE,'readwrite').objectStore(STORE).delete(String(k))}catch(e){}}};
 Storage.prototype.clear=function(){originalClear.call(this);if(this===localStorage){try{db.transaction(STORE,'readwrite').objectStore(STORE).clear()}catch(e){}}};
 window.mineDBReady=true;let s=document.createElement('script');s.src='app.js';document.body.appendChild(s);
})().catch(e=>{console.error('Local DB init failed:',e);let s=document.createElement('script');s.src='app.js';document.body.appendChild(s);alert('ذخیره‌سازی پایدار راه‌اندازی نشد؛ برنامه با ذخیره‌سازی معمولی اجرا می‌شود.')});

// Fix74: convert native Gregorian date fields into editable Persian-calendar text fields.
(function(){
 const toPersianDate=(iso)=>{if(!iso)return '';const d=new Date(iso+'T12:00:00');if(Number.isNaN(d.getTime()))return iso;return d.toLocaleDateString('fa-IR',{timeZone:'Asia/Tehran',year:'numeric',month:'2-digit',day:'2-digit'}).replace(/\u200e/g,'')};
 const upgradeDates=(root)=>{(root||document).querySelectorAll('input[type="date"]').forEach(el=>{let v=el.value;el.type='text';el.placeholder='۱۴۰۵/۰۱/۰۱';el.setAttribute('inputmode','text');el.setAttribute('autocomplete','off');if(v)el.value=toPersianDate(v);el.dataset.persianDate='true';});};
 const mo=new MutationObserver(()=>upgradeDates(document));mo.observe(document.documentElement,{childList:true,subtree:true});document.addEventListener('DOMContentLoaded',()=>upgradeDates(document));upgradeDates(document);
})();
