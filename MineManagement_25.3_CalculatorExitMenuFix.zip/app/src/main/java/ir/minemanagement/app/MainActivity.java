package ir.minemanagement.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.provider.DocumentsContract;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.content.SharedPreferences;
import android.os.Environment;
import android.util.Base64;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import android.webkit.ValueCallback;
import android.Manifest;
import android.content.pm.PackageManager;
import android.app.AlertDialog;
import android.content.Context;
import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.view.View;

public class MainActivity extends Activity {
  WebView web;
  final ArrayList<WebView> activePrintViews=new ArrayList<>();
  ValueCallback<Uri[]> uploadCallback;
  static final int FILE_CHOOSER=41;
  static final int BACKUP_FOLDER_CHOOSER=43;
  static final int EXPORT_FILE_CHOOSER=44;
  String pendingBackupJson, pendingBackupFilename;
  byte[] pendingExportBytes; String pendingExportFilename, pendingExportMime;
  static final int LOCATION_PERMISSION=42;
  String pendingGeoOrigin;
  GeolocationPermissions.Callback pendingGeoCallback;
  OnBackInvokedCallback systemBackCallback;
  @Override public void onCreate(Bundle b){
    super.onCreate(b);
    web=new WebView(this); setContentView(web);
    web.addJavascriptInterface(new PrintBridge(this), "MinePrint");
    web.addJavascriptInterface(new BackBridge(this), "MineBack");
    if(Build.VERSION.SDK_INT>=33){
      systemBackCallback=()->dispatchBackToWeb();
      getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT,systemBackCallback);
    }
    WebSettings s=web.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true); s.setAllowContentAccess(true);
    s.setGeolocationEnabled(true);
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view, String url){
        if(url!=null && url.startsWith("https://chatgpt.com")){
          try { Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse(url)); startActivity(intent); }
          catch(Exception e){ view.loadUrl(url); }
          return true;
        }
        return false;
      }
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params){
        if(uploadCallback!=null)uploadCallback.onReceiveValue(null);
        uploadCallback=cb;
        Intent i;
        try {
          i=params.createIntent();
          startActivityForResult(i,FILE_CHOOSER);
        } catch(Exception e) {
          ValueCallback<Uri[]> failed=uploadCallback;
          uploadCallback=null;
          if(failed!=null) failed.onReceiveValue(null);
          return true;
        }
        return true;
      }
      @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback){
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED ||
           checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED){
          callback.invoke(origin,true,false);
        } else if(Build.VERSION.SDK_INT>=23){
          pendingGeoOrigin=origin; pendingGeoCallback=callback;
          requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_PERMISSION);
        } else { callback.invoke(origin,false,false); }
      }
    });
    web.loadUrl("file:///android_asset/www/index.html");
  }
  @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
    super.onRequestPermissionsResult(requestCode,permissions,grantResults);
    if(requestCode==LOCATION_PERMISSION && pendingGeoCallback!=null){
      boolean granted=false; for(int r:grantResults) if(r==PackageManager.PERMISSION_GRANTED)granted=true;
      pendingGeoCallback.invoke(pendingGeoOrigin,granted,false); pendingGeoCallback=null; pendingGeoOrigin=null;
    }
  }
  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
    super.onActivityResult(requestCode,resultCode,data);
    if(requestCode==BACKUP_FOLDER_CHOOSER){
      if(resultCode==RESULT_OK && data!=null && data.getData()!=null){
        Uri treeUri=data.getData();
        try{
          int flags=data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
          getContentResolver().takePersistableUriPermission(treeUri,flags);
          Uri folderUri=ensureBackupFolder(treeUri);
          getSharedPreferences("mine_backup",MODE_PRIVATE).edit().putString("folder_uri",folderUri.toString()).putString("tree_uri",treeUri.toString()).apply();
          writeBackupFile(folderUri,pendingBackupJson,pendingBackupFilename);
        }catch(Exception e){
          android.widget.Toast.makeText(this,"ساخت پوشه modiriat.madan یا ذخیره پشتیبان ناموفق بود؛ پوشه حافظه داخلی را انتخاب کنید",android.widget.Toast.LENGTH_LONG).show();
        }
      }else{
        android.widget.Toast.makeText(this,"انتخاب پوشه انجام نشد؛ پشتیبان ذخیره نشد",android.widget.Toast.LENGTH_LONG).show();
      }
      pendingBackupJson=null; pendingBackupFilename=null;
      return;
    }
    if(requestCode==EXPORT_FILE_CHOOSER){
      if(resultCode==RESULT_OK && data!=null && data.getData()!=null && pendingExportBytes!=null){
        try(OutputStream out=getContentResolver().openOutputStream(data.getData(),"w")){
          if(out==null)throw new Exception("export-stream-null");
          out.write(pendingExportBytes);out.flush();
          android.widget.Toast.makeText(this,"فایل گزارش ذخیره شد",android.widget.Toast.LENGTH_LONG).show();
        }catch(Exception e){android.widget.Toast.makeText(this,"ذخیره فایل گزارش ناموفق بود",android.widget.Toast.LENGTH_LONG).show();}
      }else{android.widget.Toast.makeText(this,"ذخیره فایل گزارش لغو شد",android.widget.Toast.LENGTH_SHORT).show();}
      pendingExportBytes=null;pendingExportFilename=null;pendingExportMime=null;return;
    }
    if(requestCode==FILE_CHOOSER && uploadCallback!=null){
      Uri[] result=null;
      try {
        if(resultCode==RESULT_OK && data!=null)
          result=WebChromeClient.FileChooserParams.parseResult(resultCode,data);
      } catch(Exception ignored) { result=null; }
      ValueCallback<Uri[]> cb=uploadCallback;
      uploadCallback=null;
      cb.onReceiveValue(result);
    }
  }

  public class PrintBridge {
    Activity activity; PrintBridge(Activity a){activity=a;}
    @JavascriptInterface public void printHtml(String html){activity.runOnUiThread(()->{try{
      if(html==null || html.trim().isEmpty())throw new Exception("empty-print-document");
      WebView pw=new WebView(activity);pw.getSettings().setJavaScriptEnabled(false);pw.getSettings().setDomStorageEnabled(false);pw.setBackgroundColor(android.graphics.Color.WHITE);
      activePrintViews.add(pw);AtomicBoolean started=new AtomicBoolean(false);
      pw.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String url){if(!started.compareAndSet(false,true))return;try{
        PrintManager pm=(PrintManager)activity.getSystemService(Context.PRINT_SERVICE);if(pm==null)throw new Exception("print-manager-unavailable");
        PrintDocumentAdapter adapter=v.createPrintDocumentAdapter("گزارش معدن");
        pm.print("گزارش معدن",adapter,new android.print.PrintAttributes.Builder().setMediaSize(android.print.PrintAttributes.MediaSize.ISO_A4).setResolution(new android.print.PrintAttributes.Resolution("print","print",300,300)).setMinMargins(android.print.PrintAttributes.Margins.NO_MARGINS).build());
      }catch(Exception e){android.widget.Toast.makeText(activity,"باز کردن چاپ ناموفق بود: "+(e.getMessage()==null?"":e.getMessage()),android.widget.Toast.LENGTH_LONG).show();}}
      @Override public void onReceivedError(WebView v,WebResourceRequest request,WebResourceError error){if(request.isForMainFrame())android.widget.Toast.makeText(activity,"آماده‌سازی گزارش برای چاپ ناموفق بود",android.widget.Toast.LENGTH_LONG).show();}});
      pw.loadDataWithBaseURL("file:///android_asset/www/",html,"text/html","UTF-8",null);
    }catch(Exception e){android.widget.Toast.makeText(activity,"چاپ ناموفق بود",android.widget.Toast.LENGTH_LONG).show();}});}
    @JavascriptInterface public void saveBackup(String text,String filename){
      activity.runOnUiThread(()->{
        try{
          SharedPreferences prefs=getSharedPreferences("mine_backup",MODE_PRIVATE);
          String saved=prefs.getString("folder_uri",null);
          if(saved!=null){
            try{writeBackupFile(Uri.parse(saved),text,filename);return;}
            catch(Exception stale){prefs.edit().remove("folder_uri").remove("tree_uri").apply();}
          }
          pendingBackupJson=text; pendingBackupFilename=filename;
          Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
          intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
          if(Build.VERSION.SDK_INT>=26){
            try{intent.putExtra(android.provider.DocumentsContract.EXTRA_INITIAL_URI,
              DocumentsContract.buildDocumentUri("com.android.externalstorage.documents","primary:"));}
            catch(Exception ignored){}
          }
          startActivityForResult(intent,BACKUP_FOLDER_CHOOSER);
        }catch(Exception e){
          pendingBackupJson=null;pendingBackupFilename=null;
          android.widget.Toast.makeText(activity,"باز کردن انتخاب‌گر پوشه ناموفق بود",android.widget.Toast.LENGTH_LONG).show();
        }
      });
    }
    @JavascriptInterface public void saveText(String text,String filename){activity.runOnUiThread(()->{try{ContentValues values=new ContentValues();values.put(android.provider.MediaStore.Downloads.DISPLAY_NAME,filename);values.put(android.provider.MediaStore.Downloads.MIME_TYPE,"application/json");values.put(android.provider.MediaStore.Downloads.IS_PENDING,1);Uri uri=activity.getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new Exception("uri");try(OutputStream out=activity.getContentResolver().openOutputStream(uri)){if(out==null)throw new Exception("stream");out.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));}values.clear();values.put(android.provider.MediaStore.Downloads.IS_PENDING,0);activity.getContentResolver().update(uri,values,null,null);android.widget.Toast.makeText(activity,"پشتیبان در پوشه Downloads ذخیره شد",android.widget.Toast.LENGTH_LONG).show();}catch(Exception e){android.widget.Toast.makeText(activity,"ذخیره پشتیبان ناموفق بود",android.widget.Toast.LENGTH_LONG).show();}});}
    @JavascriptInterface public void saveJpg(String base64,String filename){activity.runOnUiThread(()->{try{byte[] bytes=Base64.decode(base64,Base64.DEFAULT);ContentValues values=new ContentValues();values.put(MediaStore.Images.Media.DISPLAY_NAME,filename);values.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");values.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/MineManagement");Uri uri=activity.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new Exception("uri");try(OutputStream out=activity.getContentResolver().openOutputStream(uri)){if(out==null)throw new Exception("stream");out.write(bytes);}android.widget.Toast.makeText(activity,"تصویر در پوشه Pictures/MineManagement ذخیره شد",android.widget.Toast.LENGTH_LONG).show();}catch(Exception e){android.widget.Toast.makeText(activity,"ذخیره JPG ناموفق بود",android.widget.Toast.LENGTH_LONG).show();}});}
    @JavascriptInterface public void saveFile(String base64,String filename,String mime){activity.runOnUiThread(()->{try{
      byte[] bytes=Base64.decode(base64,Base64.DEFAULT);String safeName=(filename==null||filename.trim().isEmpty())?"گزارش":filename;String safeMime=(mime==null||mime.trim().isEmpty())?"application/octet-stream":mime;
      if(Build.VERSION.SDK_INT>=29){
        ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,safeName);values.put(MediaStore.Downloads.MIME_TYPE,safeMime);values.put(MediaStore.Downloads.IS_PENDING,1);
        Uri uri=activity.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new Exception("download-uri-null");
        try(OutputStream out=activity.getContentResolver().openOutputStream(uri)){if(out==null)throw new Exception("download-stream-null");out.write(bytes);out.flush();}
        ContentValues done=new ContentValues();done.put(MediaStore.Downloads.IS_PENDING,0);activity.getContentResolver().update(uri,done,null,null);
        android.widget.Toast.makeText(activity,"فایل در پوشه Downloads ذخیره شد",android.widget.Toast.LENGTH_LONG).show();
      }else{
        pendingExportBytes=bytes;pendingExportFilename=safeName;pendingExportMime=safeMime;
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType(safeMime);intent.putExtra(Intent.EXTRA_TITLE,safeName);activity.startActivityForResult(intent,EXPORT_FILE_CHOOSER);
      }
    }catch(Exception e){android.widget.Toast.makeText(activity,"ذخیره فایل گزارش ناموفق بود",android.widget.Toast.LENGTH_LONG).show();}});}
  }
  private Uri ensureBackupFolder(Uri treeUri) throws Exception {
    String treeId=DocumentsContract.getTreeDocumentId(treeUri);
    String last=treeId.substring(treeId.lastIndexOf(':')+1);
    if("modiriat.madan".equalsIgnoreCase(last)){
      return DocumentsContract.buildDocumentUriUsingTree(treeUri,treeId);
    }
    Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(treeUri,treeId);
    Cursor c=null;
    try{
      c=getContentResolver().query(children,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE},null,null,null);
      if(c!=null)while(c.moveToNext()){
        String name=c.getString(1),mime=c.getString(2);
        if("modiriat.madan".equalsIgnoreCase(name) && DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)){
          return DocumentsContract.buildDocumentUriUsingTree(treeUri,c.getString(0));
        }
      }
    }finally{if(c!=null)c.close();}
    Uri parent=DocumentsContract.buildDocumentUriUsingTree(treeUri,treeId);
    Uri made=DocumentsContract.createDocument(getContentResolver(),parent,DocumentsContract.Document.MIME_TYPE_DIR,"modiriat.madan");
    if(made==null)throw new Exception("folder-create-failed");
    return made;
  }
  private void writeBackupFile(Uri folderUri,String json,String filename) throws Exception {
    if(json==null || filename==null)throw new Exception("backup-data-empty");
    Uri file=DocumentsContract.createDocument(getContentResolver(),folderUri,"application/json",filename);
    if(file==null)throw new Exception("file-create-failed");
    try(OutputStream out=getContentResolver().openOutputStream(file,"w")){
      if(out==null)throw new Exception("file-stream-failed");
      out.write(json.getBytes(java.nio.charset.StandardCharsets.UTF_8));
      out.flush();
    }
    android.widget.Toast.makeText(this,"پشتیبان در حافظه داخلی / modiriat.madan ذخیره شد",android.widget.Toast.LENGTH_LONG).show();
  }
  private void dispatchBackToWeb(){
    if(web!=null){
      if(web.getUrl()==null){return;}
      web.evaluateJavascript("(function(){try{if(window.mineBackController&&typeof window.mineBackController.back===\'function\'){return window.mineBackController.back();}if(typeof window.mineHandleSystemBack===\'function\'){return window.mineHandleSystemBack();}return true;}catch(e){return true;}})()",null);
    }
  }
  public class BackBridge {
    Activity activity; BackBridge(Activity a){activity=a;}
    @JavascriptInterface public void exitApp(){activity.runOnUiThread(()->activity.finish());}
  }
  // Register at DEFAULT priority so Android system edge-back/predictive gestures
  // are routed to the app without overriding higher-priority system UI.
  // Older Android versions use the legacy key/activity handlers.
  @Override public void onBackPressed(){ dispatchBackToWeb(); }
  @Override public boolean dispatchKeyEvent(android.view.KeyEvent event){
    if(event.getKeyCode()==android.view.KeyEvent.KEYCODE_BACK && event.getAction()==android.view.KeyEvent.ACTION_UP){
      if(Build.VERSION.SDK_INT<33){ dispatchBackToWeb(); return true; }
    }
    return super.dispatchKeyEvent(event);
  }
  @Override protected void onDestroy(){
    if(Build.VERSION.SDK_INT>=33 && systemBackCallback!=null){
      try{getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(systemBackCallback);}catch(Exception ignored){}
    }
    if(web!=null){web.stopLoading();web.removeJavascriptInterface("MinePrint");web.removeJavascriptInterface("MineBack");web.destroy();web=null;}
    for(WebView pw:activePrintViews){try{pw.stopLoading();pw.destroy();}catch(Exception ignored){}}activePrintViews.clear();
    super.onDestroy();
  }

}
