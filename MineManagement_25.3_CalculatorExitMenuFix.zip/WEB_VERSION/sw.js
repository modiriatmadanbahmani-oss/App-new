const CACHE='mineapp-v12-fix252-storage-report-audit';
const FILES=['./','index.html','style.css','persist.js','app.js','patches.js','manifest.json','README_FA.txt'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET')return;
  e.respondWith(caches.match(e.request,{ignoreSearch:true}).then(cached=>cached||fetch(e.request).then(response=>{
    const copy=response.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return response;
  }).catch(()=>caches.match('./index.html'))));
});
