/* Reliable IndexedDB mirror. This script must load before app.js. */
(function(){
 const DB='MineManagementLocalDB', STORE='kv', VERSION=1;
 const nativeSet=Storage.prototype.setItem, nativeRemove=Storage.prototype.removeItem, nativeClear=Storage.prototype.clear;
 let db=null, pending=Promise.resolve();
 const openDB=()=>new Promise((resolve,reject)=>{
   if(!('indexedDB' in window)) return reject(new Error('IndexedDB unavailable'));
   const req=indexedDB.open(DB,VERSION);
   req.onupgradeneeded=()=>{const d=req.result;if(!d.objectStoreNames.contains(STORE))d.createObjectStore(STORE)};
   req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error||new Error('IndexedDB open failed'));
 });
 const readAll=()=>new Promise((resolve,reject)=>{
   if(!db)return resolve([]);
   const tx=db.transaction(STORE,'readonly'),store=tx.objectStore(STORE),kr=store.getAllKeys(),vr=store.getAll();
   tx.oncomplete=()=>resolve((kr.result||[]).map((k,i)=>[String(k),String(vr.result[i]??'')]));
   tx.onerror=()=>reject(tx.error||new Error('IndexedDB read failed'));
   tx.onabort=()=>reject(tx.error||new Error('IndexedDB read aborted'));
 });
 const write=(op,key,value)=>{
   if(!db)return Promise.resolve();
   const job=pending.then(()=>new Promise((resolve,reject)=>{
     try{const tx=db.transaction(STORE,'readwrite'),s=tx.objectStore(STORE);if(op==='put')s.put(String(value),String(key));else if(op==='delete')s.delete(String(key));else s.clear();tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error||new Error('IndexedDB write failed'));tx.onabort=()=>reject(tx.error||new Error('IndexedDB write aborted'));}
     catch(e){reject(e)}
   }));
   pending=job.catch(e=>{console.warn('Local DB mirror write failed',e)});return job;
 };
 window.mineDBReady=(async()=>{
   db=await openDB();
   const saved=await readAll();
   // Preserve current localStorage values; recover keys that exist only in IndexedDB.
   for(const [k,v] of saved) if(localStorage.getItem(k)===null) nativeSet.call(localStorage,k,v);
   // Seed newly introduced / previously unmirrored local values.
   for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k!==null)await write('put',k,localStorage.getItem(k));}
   Storage.prototype.setItem=function(k,v){nativeSet.call(this,k,v);if(this===localStorage)write('put',String(k),String(v));};
   Storage.prototype.removeItem=function(k){nativeRemove.call(this,k);if(this===localStorage)write('delete',String(k));};
   Storage.prototype.clear=function(){nativeClear.call(this);if(this===localStorage)write('clear');};
   window.mineDBExportAll=async()=>{await window.mineDBFlush();const pairs=await readAll(),out={};for(const [k,v] of pairs)out[k]=v;for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k!==null)out[k]=localStorage.getItem(k)}return out;};
   window.mineDBFlush=async()=>{await pending;};
   return true;
 })();
 window.mineDBReady.catch(err=>{
   console.error('IndexedDB initialization failed; using localStorage only',err);
   window.mineDBReady=Promise.resolve(false);
   window.mineDBExportAll=async()=>{const out={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k!==null)out[k]=localStorage.getItem(k)}return out;};
   window.mineDBFlush=async()=>{};
 }).finally(()=>{
   const add=(src)=>new Promise(resolve=>{const s=document.createElement('script');s.src=src;s.onload=resolve;s.onerror=()=>{console.error('Failed to load',src);resolve()};document.body.appendChild(s)});
   add('app.js?v=252').then(()=>add('patches.js?v=252'));
 });
})();
