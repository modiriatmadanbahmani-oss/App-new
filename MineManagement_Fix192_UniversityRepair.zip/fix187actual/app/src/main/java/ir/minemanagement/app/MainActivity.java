package ir.minemanagement.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.os.Environment;
import android.util.Base64;
import java.io.OutputStream;
import android.webkit.ValueCallback;
import android.Manifest;
import android.content.pm.PackageManager;
import android.app.AlertDialog;
import android.content.Context;
import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.view.View;

public class MainActivity extends Activity {
  WebView web;
  ValueCallback<Uri[]> uploadCallback;
  static final int FILE_CHOOSER=41;
  static final int LOCATION_PERMISSION=42;
  String pendingGeoOrigin;
  GeolocationPermissions.Callback pendingGeoCallback;
  OnBackInvokedCallback systemBackCallback;
  @Override public void onCreate(Bundle b){
    super.onCreate(b);
    web=new WebView(this); setContentView(web);
    web.addJavascriptInterface(new PrintBridge(this), "MinePrint");
    web.addJavascriptInterface(new BackBridge(this), "MineBack");
    if(Build.VERSION.SDK_INT>=33){
      systemBackCallback=()->dispatchBackToWeb();
      getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT,systemBackCallback);
    }
    WebSettings s=web.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true); s.setAllowContentAccess(true);
    s.setGeolocationEnabled(true);
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view, String url){
        if(url!=null && url.startsWith("https://chatgpt.com")){
          try { Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse(url)); startActivity(intent); }
          catch(Exception e){ view.loadUrl(url); }
          return true;
        }
        return false;
      }
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params){
        if(uploadCallback!=null)uploadCallback.onReceiveValue(null);
        uploadCallback=cb;
        Intent i;
        try {
          i=params.createIntent();
          startActivityForResult(i,FILE_CHOOSER);
        } catch(Exception e) {
          ValueCallback<Uri[]> failed=uploadCallback;
          uploadCallback=null;
          if(failed!=null) failed.onReceiveValue(null);
          return true;
        }
        return true;
      }
      @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback){
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED ||
           checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED){
          callback.invoke(origin,true,false);
        } else if(Build.VERSION.SDK_INT>=23){
          pendingGeoOrigin=origin; pendingGeoCallback=callback;
          requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_PERMISSION);
        } else { callback.invoke(origin,false,false); }
      }
    });
    web.loadUrl("file:///android_asset/www/index.html");
  }
  @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
    super.onRequestPermissionsResult(requestCode,permissions,grantResults);
    if(requestCode==LOCATION_PERMISSION && pendingGeoCallback!=null){
      boolean granted=false; for(int r:grantResults) if(r==PackageManager.PERMISSION_GRANTED)granted=true;
      pendingGeoCallback.invoke(pendingGeoOrigin,granted,false); pendingGeoCallback=null; pendingGeoOrigin=null;
    }
  }
  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
    super.onActivityResult(requestCode,resultCode,data);
    if(requestCode==FILE_CHOOSER && uploadCallback!=null){
      Uri[] result=null;
      try {
        if(resultCode==RESULT_OK && data!=null)
          result=WebChromeClient.FileChooserParams.parseResult(resultCode,data);
      } catch(Exception ignored) { result=null; }
      ValueCallback<Uri[]> cb=uploadCallback;
      uploadCallback=null;
      cb.onReceiveValue(result);
    }
  }

  public class PrintBridge {
    Activity activity; PrintBridge(Activity a){activity=a;}
    @JavascriptInterface public void printHtml(String html){activity.runOnUiThread(()->{try{WebView pw=new WebView(activity);pw.getSettings().setJavaScriptEnabled(false);pw.loadDataWithBaseURL(null,html,"text/html","UTF-8",null);pw.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String url){try{PrintManager pm=(PrintManager)activity.getSystemService(Context.PRINT_SERVICE);PrintDocumentAdapter adapter=v.createPrintDocumentAdapter("گزارش معدن");pm.print("گزارش معدن",adapter,new android.print.PrintAttributes.Builder().setMediaSize(android.print.PrintAttributes.MediaSize.ISO_A4).setResolution(new android.print.PrintAttributes.Resolution("print","print",300,300)).setMinMargins(android.print.PrintAttributes.Margins.NO_MARGINS).build());}catch(Exception e){android.widget.Toast.makeText(activity,"باز کردن چاپ ناموفق بود",android.widget.Toast.LENGTH_LONG).show();}}});}catch(Exception e){android.widget.Toast.makeText(activity,"چاپ ناموفق بود",android.widget.Toast.LENGTH_LONG).show();}});}
    @JavascriptInterface public void saveText(String text,String filename){activity.runOnUiThread(()->{try{ContentValues values=new ContentValues();values.put(android.provider.MediaStore.Downloads.DISPLAY_NAME,filename);values.put(android.provider.MediaStore.Downloads.MIME_TYPE,"application/json");values.put(android.provider.MediaStore.Downloads.IS_PENDING,1);Uri uri=activity.getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new Exception("uri");try(OutputStream out=activity.getContentResolver().openOutputStream(uri)){if(out==null)throw new Exception("stream");out.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));}values.clear();values.put(android.provider.MediaStore.Downloads.IS_PENDING,0);activity.getContentResolver().update(uri,values,null,null);android.widget.Toast.makeText(activity,"پشتیبان در پوشه Downloads ذخیره شد",android.widget.Toast.LENGTH_LONG).show();}catch(Exception e){android.widget.Toast.makeText(activity,"ذخیره پشتیبان ناموفق بود",android.widget.Toast.LENGTH_LONG).show();}});}
    @JavascriptInterface public void saveJpg(String base64,String filename){activity.runOnUiThread(()->{try{byte[] bytes=Base64.decode(base64,Base64.DEFAULT);ContentValues values=new ContentValues();values.put(MediaStore.Images.Media.DISPLAY_NAME,filename);values.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");values.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/MineManagement");Uri uri=activity.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new Exception("uri");try(OutputStream out=activity.getContentResolver().openOutputStream(uri)){if(out==null)throw new Exception("stream");out.write(bytes);}android.widget.Toast.makeText(activity,"تصویر در پوشه Pictures/MineManagement ذخیره شد",android.widget.Toast.LENGTH_LONG).show();}catch(Exception e){android.widget.Toast.makeText(activity,"ذخیره JPG ناموفق بود",android.widget.Toast.LENGTH_LONG).show();}});}
  }
  private void dispatchBackToWeb(){
    if(web!=null){
      if(web.getUrl()==null){return;}
      web.evaluateJavascript("(function(){try{if(window.mineBackController&&typeof window.mineBackController.back===\'function\'){return window.mineBackController.back();}if(typeof window.mineHandleSystemBack===\'function\'){return window.mineHandleSystemBack();}return true;}catch(e){return true;}})()",null);
    }
  }
  public class BackBridge {
    Activity activity; BackBridge(Activity a){activity=a;}
    @JavascriptInterface public void exitApp(){activity.runOnUiThread(()->activity.finish());}
  }
  // Register at DEFAULT priority so Android system edge-back/predictive gestures
  // are routed to the app without overriding higher-priority system UI.
  // Older Android versions use the legacy key/activity handlers.
  @Override public void onBackPressed(){ dispatchBackToWeb(); }
  @Override public boolean dispatchKeyEvent(android.view.KeyEvent event){
    if(event.getKeyCode()==android.view.KeyEvent.KEYCODE_BACK && event.getAction()==android.view.KeyEvent.ACTION_UP){
      if(Build.VERSION.SDK_INT<33){ dispatchBackToWeb(); return true; }
    }
    return super.dispatchKeyEvent(event);
  }
  @Override protected void onDestroy(){
    if(Build.VERSION.SDK_INT>=33 && systemBackCallback!=null){
      try{getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(systemBackCallback);}catch(Exception ignored){}
    }
    if(web!=null){web.stopLoading();web.removeJavascriptInterface("MinePrint");web.removeJavascriptInterface("MineBack");web.destroy();web=null;}
    super.onDestroy();
  }

}
